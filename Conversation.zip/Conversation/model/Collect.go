package model

type Collect struct {
	Id     int `xorm:"pk autoincr" json:"id"`
	UserId int `xorm:"int(10)" json:"user_id"`

	//稿件Id
	Cid int `xorm:"int(10)" json:"cid"`
}
