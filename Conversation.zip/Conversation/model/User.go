package model

import "time"

type User struct {
	Id       int    `xorm:"pk autoincr" json:"id"`
	UserName string `xorm:"varchar(11)" json:"user_name"`
	//身份
	Identity string `xorm:"varchar(11)" json:"identity"`
	//关注状态
	Status    int `xorm:"int(11)" json:"status"`
	FanStatus int `xorm:"int(10)" json:"fan_status"`
	//黑名单
	BlackList string `xorm:"varchar(11)" json:"black_list"`
	//用户投稿数量
	UserContributionNum int `xorm:"int(10)" json:"user_contribution_num"`
	//头像
	Image string `xorm:"varchar(255)" json:"image"`
	//签名
	Autograph string `xorm:"varchar(255)" json:"autograph"`
	//关注数量
	Follow int `xorm:"int(10)" json:"follow"`
	//粉丝数量
	Fan int `xorm:"int(10)" json:"fan"`
	//获赞数量
	LikeNum int `xorm:"int(10)" json:"like_num"`
	//点赞的稿件id
	LikeCid []int `xorm:"varchar(255)" json:"like_cid"`
	//创建时间
	CreatedAt time.Time `xorm:"created"`
}
