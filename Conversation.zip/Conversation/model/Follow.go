package model

type Follow struct {
	Id int `xorm:"pk autoincr" json:"id"`
	UserId int `xorm:"int(10)" json:"user_id"`

	FollowStatus int `xorm:"int(10)" json:"follow_status"`

	FanStatus int `xorm:"int(10)" json:"fan_status"`

	UserId2 int `xorm:"int(10)" json:"user_id_2"`


}
