package model

type MsgBroad struct {
	Id             int `xorm:"pk autoincr" json:"id"`
	UserId         int `xorm:"int(10)" json:"user_id"`
	ContributionId int `xorm:"int(10)" json:"contribution_id" `

	Msg       string `xorm:"varchar(255)" json:"msg"`
	MsgNum    int    `xorm:"int(10)" json:"msg_num"`
	MsgStatus int    `xorm:"int(10)" json:"msg_status"`
	User      `xorm:"extends"`
}
