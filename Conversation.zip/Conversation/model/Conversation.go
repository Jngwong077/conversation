package model

import "time"

type Conversation struct {
	Id     int `xorm:"pk autoincr" json:"id"`
	UserId int `xorm:"int(255)" json:"user_id"`
	//话题标题
	TownTalkTitle string `xorm:"varchar(255)" json:"town_talk_title"`
	//话题信息
	TownTalkInfo string `xorm:"varchar(255)" json:"town_talk_info"`
	//话题参与人数
	FollowNum int `xorm:"int(10)" json:"follow_num"`
	//话题状态
	TownTalkStatus string `xorm:"varchar(255)" json:"town_talk_status" `
	//投稿数量
	ContributionNum int `xorm:"int(5)" json:"contribution_num"`
	//用户头像图片
	UserAvatar string `xorm:"varchar(255)" json:"user_avatar"`

	CreatedAt time.Time `xorm:"created"`
}
