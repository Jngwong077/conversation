package model

import "time"

type Contribution struct {
	Id             int    `xorm:"pk autoincr" json:"id"`
	UserId         int    `xorm:"int(10)" json:"user_id"`
	ConversationId string `xorm:"varchar(10)" json:"conversation_id"`
	UserName       string `xorm:"varchar(255)" json:"user_name"`
	UserAvatar     string `xorm:"varchar(255)" json:"user_avatar"`
	//黑名单
	BlackList string `xorm:"varchar(11)" json:"black_list"`
	//投稿状态，是否可投稿
	ContributionStatus int `xorm:"int(11)" json:"contribution_status"`
	//用户投稿图片
	UserContributionImage string `xorm:"varchar(255)" json:"user_contribution_image"`
	//用户投稿信息
	UserContributionInfo string `xorm:"varchar(255)" json:"user_contribution_info"`
	//话题标题
	TownTalkTitle string `xorm:"varchar(255)" json:"town_talk_title"`
	//点赞数量
	LikeNum int `xorm:"int(10)" json:"like_num"`
	//创建时间
	CreatedAt time.Time `xorm:"created"`
}
