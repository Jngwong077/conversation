package dao

import (
	"Conversation/model"
	"Conversation/param"
	"Conversation/tool"
	"fmt"
)

type ContributionDao struct {
	*tool.Orme
}

func NewContributionDao() *ContributionDao {
	return &ContributionDao{tool.DbEngine}
}

//获取我的稿件
func (cd *ContributionDao) ContributionMyDao(uid int) ([]model.Contribution, error) {
	var con []model.Contribution
	err := cd.Where("user_id = ?", uid).Find(&con)
	if err != nil {
		fmt.Println("获取我的稿件失败")
		return nil, err
	}
	return con, nil
}

//获取所有稿件
func (cd *ContributionDao) CtbDao() ([]model.Contribution, error) {
	var ctb []model.Contribution
	err := cd.Engine.Desc("created_at").Find(&ctb)
	if err != nil {
		fmt.Println("获取稿件信息失败")
		return nil, err
	}

	return ctb, nil
}

//编辑稿件
func (cd *ContributionDao) ContributionEditDao(cp param.ConvParam, filename string) (int64, error) {

	con := model.Contribution{
		UserContributionInfo:  cp.TownTalkInfo,
		TownTalkTitle:         cp.TownTalkTitle,
		UserContributionImage: filename,
	}
	result, err := cd.Where("user_id = ?", cp.UserId).Update(&con)

	if err != nil {
		fmt.Println("编辑稿件表失败")
		return 0, err
	}
	return result, nil
}
