package dao

import (
	"Conversation/model"
	"Conversation/param"
	"Conversation/tool"
	"fmt"
)

type UserDao struct {
	*tool.Orme
}

func NewUserInfo() *UserDao {
	return &UserDao{tool.DbEngine}
}

func (ud *UserDao) GetUserDao() (*model.User, error) {
	getUser := new(model.User)
	_, err := ud.Where("id = ?", 16).Get(getUser)
	if err != nil {
		return nil, err
	}
	return getUser, nil
}

func (ud *UserDao) GetUserNameDao(un string) (*model.User, error) {
	gu := new(model.User)
	_, err := ud.Where("user_name = ?", un).Get(gu)
	if err != nil {
		fmt.Println(err.Error())
		return nil, err
	}
	return gu, nil

}

func (ud *UserDao) SearchOneUserDao(un string) ([]model.Contribution, error) {
	var oneUser []model.Contribution
	err := ud.Where("user_name = ?", un).Find(&oneUser)
	if err != nil {
		fmt.Println(err.Error())
		return nil, err
	}
	return oneUser, nil

}

//修改用户头像
func (ud *UserDao) UploadAvaDao(id string, filename string) (int64, error) {
	ui := model.User{Image: filename}
	cui := model.Contribution{UserAvatar: filename}
	ci := model.Conversation{UserAvatar: filename}
	result, err := ud.Where("id = ?", id).Update(&ui)
	if err != nil {
		fmt.Println("图像插入数据库失败", err)
		return 0, err
	}

	result, err = ud.Where("user_id = ?", id).Update(&cui)
	if err != nil {
		fmt.Println("更新稿件头像失败", err)
		return 0, err
	}

	result, err = ud.Where("user_id = ?", id).Update(&ci)
	if err != nil {
		fmt.Println("更新话题头像失败", err)
		return 0, err
	}

	_, err = ud.Exec("update msg_broad set image = ? where user_id = ?", filename, id)
	if err != nil {
		fmt.Println("更新留言头像失败", err)
		return 0, err
	}

	return result, nil
}

//查询所有用户信息
func (ud *UserDao) QueryInfo(pageNum int, pageSize int) ([]model.User, error) {
	//var info []model.User
	//err := ud.Engine.Find(&info)
	//if err != nil {
	//	return nil, err
	//}
	//for _, infos := range info {
	//	if infos.Status != "0" {
	//		ud.Exec("update user set status = ? where status = ?", "已关注", infos.Status)
	//	}
	//}

	ino := make([]model.User, 0, 10)
	ud.SQL("select * from user limit ?, ?", pageNum, pageSize).Desc("created_at").Find(&ino)

	return ino, nil
}

//查询用户信息
func (ud *UserDao) QueryUser(username string) ([]model.User, error) {
	var users []model.User
	err := ud.Where("user_name like ?", "%"+username+"%").Find(&users)
	if err != nil {
		fmt.Println(err.Error())
		return nil, err
	}
	ud.Prepare()
	return users, nil
}

//编辑用户
func (ud *UserDao) EditUser(editParamDao param.EditUserParam) ([]model.User, error) {
	var users []model.User
	err := ud.Where("id like ?", editParamDao.Id).Find(&users)
	if err != nil {
		fmt.Println(err.Error())
		return nil, err
	}
	for _, user := range users {
		ud.Exec("update user set user_name = ?,autograph = ? where id = ? ",
			editParamDao.UserName, editParamDao.Autograph, user.Id)

		exist, _ := ud.Table("contribution").Where("user_id = ?", user.Id).Exist()
		if exist == true {
			ud.Exec("update contribution set user_name = ? where user_id = ?",
				editParamDao.UserName, user.Id)
		}

		exist, _ = ud.Table("msg_broad").Where("user_id = ?", user.Id).Exist()
		if exist == true {
			ud.Exec("update msg_broad set user_name = ? where user_id = ?",
				editParamDao.UserName, user.Id)
		}

		//ud.Exec("update contribution set user_name = ? where user_did = ?",editParamDao.UserName,user.Id)
	}
	var user []model.User
	ud.Where("id like ?", editParamDao.Id).Find(&user)
	return user, nil
}

//增加用户
func (ud *UserDao) AddUserDao(au param.EditUserParam) (int64, error) {
	//exist, err := ud.SQL("SELECT * FROM user where user_name = ?", au.UserName).Exist()
	exist, err := ud.Table("user").Where("user_name = ?", au.UserName).Exist()
	if exist == true {
		return 0, err
	}
	//ud.Exec("INSERT INTO user(user_name,autograph,identity) VALUES(?,?,?)",
	//	au.UserName, au.Autograph, au.Identity)

	user := model.User{
		UserName:  au.UserName,
		Autograph: au.Autograph,
		Identity:  au.Identity,
		Image:     "/uploadfile/用户默认头像.jpg",
	}
	_, err = ud.Insert(&user)
	if err != nil {
		fmt.Println("添加到用户数据库失败", err)
		return 0, err
	}
	return 1, nil
}

//删除用户
func (ud *UserDao) DeleteUserDao(id string) (int64, error) {
	//exist, err := ud.SQL("SELECT * FROM user where id = ?", id).Exist()
	exist, err := ud.Table("user").Where("id = ?", id).Exist()
	if exist != true {
		return 0, err
	}
	ud.Exec("DELETE FROM user where id=?", id)

	return 1, nil
}
