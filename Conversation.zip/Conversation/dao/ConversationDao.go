package dao

import (
	"Conversation/model"
	"Conversation/param"
	"Conversation/tool"
	"fmt"
)

type ConversationDao struct {
	*tool.Orme
}

func NewConvInfo() *ConversationDao {
	return &ConversationDao{tool.DbEngine}
}

//话题合集
func (cd *ConversationDao) ConvInfo(pageSize int, pageNum int) ([]model.Conversation, error) {
	var convInfo []model.Conversation
	err := cd.Engine.Find(&convInfo)
	if err != nil {
		return nil, err
	}

	for _, conv := range convInfo {
		if conv.TownTalkStatus != "0" {
			cd.Exec("update conversation set town_talk_status = ? where town_talk_status = ?",
				"已结束", conv.TownTalkStatus)
		}
	}

	var con []model.Conversation
	err = cd.Orme.Limit(pageSize, pageNum).Find(&con)
	if err != nil {
		return nil, err
	}
	return con, nil
}

//搜索话题
func (cd *ConversationDao) SearchConv(convTitle string) ([]model.Conversation, error) {
	var searchConv []model.Conversation
	err := cd.Where("town_talk_title like ?", "%"+convTitle+"%").Find(&searchConv)
	if err != nil {
		fmt.Println(err.Error())
		return nil, err
	}
	return searchConv, nil
}

//点击话题后的显示
func (cd *ConversationDao) SearchConvOne(convTitle string) ([]model.Contribution, error) {
	var searchConv []model.Conversation
	err := cd.Where("town_talk_title like ?", convTitle).Find(&searchConv)
	if err != nil {
		fmt.Println(err.Error())
		return nil, err
	}

	for _, conv := range searchConv {
		if conv.ContributionNum > 5 {
			cd.Exec("update contribution set contribution_status = ? where town_talk_title = ?",
				1, convTitle)
		}
	}

	var contribu []model.Contribution
	err = cd.Where("town_talk_title like ?", convTitle).Find(&contribu)
	if err != nil {
		fmt.Println(err.Error())
		return nil, err
	}

	return contribu, nil
}

//投稿图文
func (cd *ConversationDao) ConvAddDao(convParam param.ConvParam, filename string) (int64, error) {
	//话题数据库插入
	_, err := cd.Exec("INSERT INTO conversation(user_id, town_talk_title, town_talk_info) VALUES(?,?,?)",
		convParam.UserId, convParam.TownTalkTitle, convParam.TownTalkInfo)
	if err != nil {
		fmt.Println("插入话题数据失败")
		return 0, err
	}
	cd.Exec("update conversation set contribution_num = contribution_num + 1 where town_talk_title = ?", convParam.TownTalkTitle)

	//稿件数据库插入
	if err != nil {
		return 0, err
	}
	ui := model.Contribution{
		UserId:                convParam.UserId,
		UserContributionInfo:  convParam.TownTalkInfo,
		TownTalkTitle:         convParam.TownTalkTitle,
		UserContributionImage: filename,
	}

	result, err := cd.Insert(&ui)
	if err != nil {
		fmt.Println("插入到稿件数据库失败", err)
		return 0, err
	}

	_, err = cd.Exec("update user set user_contribution_num = user_contribution_num + 1 where id = ?", convParam.UserId)
	if err != nil {
		fmt.Println("更新用户数据库失败")
		return 0, err
	}

	//更新用户信息
	var user []model.User
	err = cd.Where("id = ?", convParam.UserId).Find(&user)
	if err != nil {
		fmt.Println("获取用户信息失败")
		return 0, err
	}
	var username, userAvatar string
	for _, u := range user {
		if u.Id == convParam.UserId {
			username = u.UserName
			userAvatar = u.Image
		}
	}

	_, err = cd.Exec("update contribution set user_name = ?,user_avatar =?  where user_id = ?",
		username, userAvatar, convParam.UserId)
	if err != nil {
		fmt.Println("插入用户信息失败")
		return 0, err
	}
	return result, nil
}
