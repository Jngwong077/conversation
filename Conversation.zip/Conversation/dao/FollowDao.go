package dao

import (
	"Conversation/model"
	"Conversation/tool"
	"fmt"
)

type FollowDao struct {
	*tool.Orme
}

func NewFollowDao() *FollowDao {
	return &FollowDao{tool.DbEngine}
}

//添加用户关注
func (fd *FollowDao) FollowAddDao(uid int, uid2 int) (int, error) {
	exist, err := fd.Table("follow").Where("user_id = ? and user_id2 = ?", uid, uid2).Exist()
	if err != nil {
		fmt.Println(err)
		return 0, err
	}

	if exist == true {
		_, err := fd.Exec("update follow set follow_status = follow_status + 2 "+
			"WHERE user_id = ? and user_id2 = ?", uid, uid2)
		if err != nil {
			fmt.Println("更新关注状态失败")
			return 0, err
		}

		_, err = fd.Exec("update follow set follow_status = follow_status + 1,"+
			"fan_status = fan_status + 1 "+
			"WHERE user_id = ? and user_id2 = ?", uid2, uid)
		if err != nil {
			fmt.Println("更新关注状态及粉丝状态失败")
			return 0, err
		}

		//相对于更新用户状态，设为相互关注
		_, err = fd.Exec("update user set status = 2 where id = ?", uid2)
		if err != nil {
			fmt.Println("更新关注用户表粉丝失败")
			return 0, err
		}

	} else {
		_, err = fd.Exec("insert into follow(user_id, follow_status, user_id2) value(?,?,?) ",
			uid, 1, uid2)
		if err != nil {
			fmt.Println("插入关注状态失败")
			return 0, err
		}

		_, err = fd.Exec("insert into follow(user_id, fan_status, user_id2) value(?,?,?) ",
			uid2, 1, uid)
		if err != nil {
			fmt.Println("插入粉丝状态失败")
			return 0, err
		}

		//相对于更新用户状态，设为已关注
		_, err = fd.Exec("update user set status = 1 where id = ?", uid2)
		if err != nil {
			fmt.Println("更新关注用户表粉丝失败")
			return 0, err
		}

	}

	//同步更新用户数据库
	_, err = fd.Exec("update user set follow = follow + 1 where id = ?", uid)
	if err != nil {
		fmt.Println("更新关注用户表粉丝失败")
		return 0, err
	}

	_, err = fd.Exec("update user set fan = fan + 1 where id = ?", uid2)
	if err != nil {
		fmt.Println("更新关注用户表粉丝失败")
		return 0, err
	}

	return 1, nil
}

//取消用户关注
func (fd *FollowDao) FollowCancelDao(uid int, uid2 int) (int, error) {
	var follow []model.Follow
	err := fd.Where("user_id = ?", uid).Find(&follow)
	if err != nil {
		fmt.Println("查询用户表失败")
		return 0, err
	}

	for _, f := range follow {
		if f.FollowStatus == 1 {
			_, err := fd.Exec("DELETE FROM follow WHERE user_id in(?, ?) and user_id2 in(?, ?)",
				uid, uid2, uid2, uid)
			if err != nil {
				fmt.Println("删除单方面关注失败")
				return 0, err
			}

			_, err = fd.Exec("update user set status = 0 where id = ?", uid2)
			if err != nil {
				fmt.Println("更新用户表状态失败")
				return 0, err
			}

		}

		if f.FollowStatus == 2 {
			_, err = fd.Exec("update follow set follow_status = 0 "+
				"WHERE user_id = ? and user_id2 = ?", uid, uid2)
			if err != nil {
				fmt.Println("单方面取消关注状态更新失败")
				return 0, err
			}

			_, err = fd.Exec("update follow set follow_status = 1,"+
				"fan_status = 0 "+
				"WHERE user_id = ? and user_id2 = ?", uid2, uid)
			if err != nil {
				fmt.Println("被动更新关注状态失败")
				return 0, err
			}

			_, err = fd.Exec("update user set status = 0 where id = ?", uid2)
			if err != nil {
				fmt.Println("取消关注用户表状态失败")
				return 0, err
			}

		}
	}
	//同步更新用户数据库
	_, err = fd.Exec("update user set follow = follow - 1 where id = ?", uid)
	if err != nil {
		fmt.Println("更新关注用户表粉丝失败")
		return 0, err
	}

	_, err = fd.Exec("update user set fan = fan - 1 where id = ?", uid2)
	if err != nil {
		fmt.Println("更新关注用户表粉丝失败")
		return 0, err
	}
	return 1, nil
}

//获取粉丝信息
func (fd *FollowDao) FanGetDao(uid int) ([]model.User, error) {
	var fan []model.Follow
	err := fd.Where("user_id = ?", uid).Find(&fan)
	if err != nil {
		fmt.Println("查询关注表里的粉丝失败")
		return nil, err
	}
	var u []model.User
	for _, i := range fan {
		//err := fd.Join("INNER","follow","follow.user_id2 = user.id").
		//	    Where("user.id = ?", i.UserId2).Find(&us)
		if i.FanStatus != 0 {
			_, err := fd.Exec("update user set fan_status = 1 where user.id = ?", i.UserId2)
			if err != nil {
				fmt.Println("更新粉丝状态信息失败")
				return nil, err
			}
			err = fd.Where("user.id = ?", i.UserId2).Find(&u)
			if err != nil {
				fmt.Println("查询粉丝信息失败")
				return nil, err
			}
		}

	}

	return u, nil
}

//获取关注信息
func (fd *FollowDao) FollowGetDao(uid int) ([]model.User, error) {
	var follow []model.Follow
	err := fd.Where("user_id = ?", uid).Find(&follow)
	if err != nil {
		fmt.Println("查询关注表失败")
		return nil, err
	}
	var u []model.User
	for _, i := range follow {
		//err := fd.Join("INNER","follow","follow.user_id2 = user.id").
		//	    Where("user.id = ?", i.UserId2).Find(&us)

		if i.FollowStatus == 1 {
			_, err = fd.Exec("update user set status = 1 where user.id = ?", i.UserId2)
			if err != nil {
				fmt.Println("更新单方面关注用户信息失败")
				return nil, err
			}
		} else if i.FollowStatus == 2 {
			_, err = fd.Exec("update user set status = 2 where user.id = ?", i.UserId2)
			if err != nil {
				fmt.Println("更新互相关注用户信息失败")
				return nil, err
			}
		} else {
			_, err = fd.Exec("update user set status = 0 where user.id = ?", i.UserId2)
			if err != nil {
				fmt.Println("更新用户未关注信息失败")
				return nil, err
			}
		}

		if i.FollowStatus != 0 {
			err = fd.Where("user.id = ?", i.UserId2).Find(&u)
			if err != nil {
				fmt.Println("查询用户关注信息失败")
				return nil, err
			}
		}

	}
	return u, nil
}

//获取互相关注用户信息
func (fd *FollowDao) FollowEachDao(uid int) ([]model.User, error) {
	var follow []model.Follow
	err := fd.Where("user_id = ?", uid).Find(&follow)
	if err != nil {
		fmt.Println("查询互相关注用户失败")
		return nil, err
	}
	var us []model.User
	for _, i := range follow {
		//err := fd.Join("INNER","follow","follow.user_id2 = user.id").
		//	    Where("user.id = ?", i.UserId2).Find(&us)
		if i.FollowStatus == 2 {
			err := fd.Where("user.id = ?", i.UserId2).Find(&us)
			if err != nil {
				fmt.Println("查询互相用户关注信息失败")
				return nil, err
			}
		}
	}
	return us, nil
}
