package dao

import (
	"Conversation/model"
	"Conversation/tool"
	"encoding/json"
	"fmt"
)

type LikeDao struct {
	*tool.Orme
}

func NewLikeAndCollectDao() *LikeDao {
	return &LikeDao{tool.DbEngine}
}

//获取点赞我的用户
func (ld *LikeDao) LikeMeDao(uid int) ([]model.User, []model.Contribution, error) {
	var my []model.Contribution
	err := ld.Where("user_id = ?", uid).Find(&my)
	if err != nil {
		fmt.Println("获取我的稿件失败")
	}

	var like []model.Like
	for _, c := range my {
		err := ld.Where("cid = ?", c.Id).Find(&like)
		if err != nil {
			fmt.Println("获取点赞表信息失败")
		}
	}

	var user []model.User
	for _, l := range like {
		err := ld.Where("id = ?", l.UserId).Find(&user)
		if err != nil {
			fmt.Println("获取点赞用户信息失败")
		}
	}

	return user, my, nil
}

//获取我的点赞
func (ld *LikeDao) LikeYouDao(uid int) ([]model.Contribution, error) {
	var likeUser []model.Like
	err := ld.Where("user_id = ? ", uid).Find(&likeUser)
	if err != nil {
		fmt.Println("获取点赞表失败")
		return nil, err
	}
	var con []model.Contribution
	for _, l := range likeUser {
		err := ld.Where("id = ?", l.Cid).Find(&con)
		if err != nil {
			fmt.Println("查询稿件表失败")
			return nil, err
		}
	}
	return con, nil
}

//添加点赞
func (ld *LikeDao) LikeAddDao(uid int, cid int) (int, error) {
	like := model.Like{UserId: uid, Cid: cid}
	_, err := ld.Insert(&like)
	if err != nil {
		fmt.Println("插入点赞表失败")
		return 0, err
	}
	//更新点赞表的点赞数量
	_, err = ld.Exec("update contribution set like_num = like_num + 1 "+
		"where id = ?", cid)
	if err != nil {
		fmt.Println("更新稿件表数据失败")
		return 0, err
	}

	var user []model.User
	err = ld.Where("id = ?", uid).Find(&user)
	if err != nil {
		fmt.Println("查询用户表失败！")
		return 0, err
	}
	//以数组方式将cid添加到用户表
	var cIdArray []int
	for _, us := range user {
		cIdArray = append(us.LikeCid, cid)
		str, _ := json.Marshal(cIdArray)

		_, err = ld.Exec("update user set like_cid = ? where id = ?", str, uid)
		if err != nil {
			fmt.Println("更新用户表点赞数据失败")
			return 0, err
		}
	}

	//根据cid去查询对应的用户
	var con []model.Contribution
	err = ld.Where("id = ?", cid).Find(&con)
	if err != nil {
		fmt.Println("查询稿件表失败！")
		return 0, err
	}

	for _, c := range con {
		_, err = ld.Exec("update user set like_num = like_num + 1 "+
			"where id = ?", c.UserId)
		if err != nil {
			fmt.Println("更新用户表数据失败")
			return 0, err
		}
	}
	return 1, nil
}

//取消点赞
func (ld *LikeDao) LikeCancelDao(uid int, cid int) (int, error) {
	like := model.Like{UserId: uid, Cid: cid}

	_, err := ld.Delete(&like)
	if err != nil {
		fmt.Println("删除点赞表失败")
		return 0, err
	}

	//删除用户表中的cid
	var user []model.User
	err = ld.Where("id = ?", uid).Find(&user)
	if err != nil {
		fmt.Println("查询用户表失败！")
		return 0, err
	}

	for _, us := range user {
		for i := 0; i < len(us.LikeCid); {
			if us.LikeCid[i] == cid {
				us.LikeCid = append(us.LikeCid[:i], us.LikeCid[i+1:]...)
				str, _ := json.Marshal(us.LikeCid)
				_, err = ld.Exec("update user set like_cid = ? where id = ?", str, uid)
				if err != nil {
					fmt.Println("更新用户表点赞数据失败")
					return 0, err
				}
			} else {
				i++
			}
		}
	}

	//更新稿件表的点赞数量
	_, err = ld.Exec("update contribution set like_num = like_num - 1 "+
		"where id = ?", cid)
	if err != nil {
		fmt.Println("更新稿件表表失败")
		return 0, err
	}

	var con []model.Contribution
	err = ld.Where("id = ?", cid).Find(&con)
	if err != nil {
		fmt.Println("查询稿件表失败！")
		return 0, err
	}

	for _, c := range con {
		_, err = ld.Exec("update user set like_num = like_num - 1 "+
			"where id = ?", c.UserId)
		if err != nil {
			fmt.Println("更新用户表数据失败")
			return 0, err
		}
	}

	return 1, nil
}

//收藏信息
func (ld *LikeDao) CollectDao(uid int) ([]model.Contribution, error) {
	var collect []model.Collect
	err := ld.Where("user_id = ?", uid).Find(&collect)
	if err != nil {
		fmt.Println("查询收藏表信息失败")
		return nil, err
	}

	var con []model.Contribution
	for _, c := range collect {
		err := ld.Where("id = ?", c.Cid).Find(&con)
		if err != nil {
			fmt.Println("查询稿件表失败")
			return nil, err
		}
	}
	return con, nil
}

//添加收藏
func (ld *LikeDao) CollectAddDao(uid int, cid int) (int, error) {
	collect := model.Collect{
		UserId: uid,
		Cid:    cid,
	}
	_, err := ld.Insert(&collect)
	if err != nil {
		fmt.Println("插入收藏表失败")
		return 0, err
	}
	return 1, err
}

//取消收藏
func (ld *LikeDao) CollectCancelDao(uid int, cid int) (int, error) {
	collect := model.Collect{
		UserId: uid,
		Cid:    cid,
	}
	_, err := ld.Delete(&collect)
	if err != nil {
		fmt.Println("删除收藏表失败")
		return 0, err
	}
	return 1, err
}
