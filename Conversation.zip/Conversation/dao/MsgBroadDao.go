package dao

import (
	"Conversation/model"
	"Conversation/param"
	"Conversation/tool"
	"fmt"
	"time"
)

type MsgBroadDao struct {
	*tool.Orme
}

func NewMsgBroadDao() *MsgBroadDao {
	return &MsgBroadDao{tool.DbEngine}
}

func (md *MsgBroadDao) MsgDao(cid int) ([]model.MsgBroad, error) {
	var msg []model.MsgBroad
	err := md.Where("contribution_id = ?", cid).Find(&msg)
	if err != nil {
		fmt.Println("搜索稿件失败")
		return nil, err
	}
	_, err = md.Exec("UPDATE msg_broad,user " +
		"set msg_broad.image = user.image," +
		"msg_broad.user_name = user.user_name " +
		"where user.id = msg_broad.user_id")
	if err != nil {
		fmt.Println("更新数据失败")
		return nil, err
	}
	var mg []model.MsgBroad
	err = md.Where("contribution_id = ?", cid).Desc("created_at").Find(&mg)

	return mg, nil
}

func (md *MsgBroadDao) MsgAddDao(mp param.MsgBroadParam) (int, error) {
	msg := model.MsgBroad{
		UserId:         mp.UserId,
		ContributionId: mp.ContributionId,
		Msg:            mp.Msg,
	}
	_, err := md.Insert(&msg)
	if err != nil {
		fmt.Println("插入数据失败")
		return 0, err
	}
	return 1, nil
}

func (md *MsgBroadDao) MsgReportDao() (int, error) {
	return 0, nil
}

func (md *MsgBroadDao) MsgTopDao(mid int) (int, error) {

	_, err := md.Exec("update msg_broad set created_at = ? where id = ?",
		time.Now(), mid)
	if err != nil {
		fmt.Println("修改评论表时间失败！")
		return 0, err
	}
	return 1, nil

}

func (md *MsgBroadDao) MsgReplyDao() (int, error) {
	return 0, nil
}

func (md *MsgBroadDao) MsgDeleteDao() (int, error) {
	return 0, nil
}
