package main

import (
	"Conversation/controller"
	"Conversation/tool"
	"github.com/gin-gonic/gin"
	"net/http"
)

func main() {
	cfg, err := tool.ParseConfig("./config/app.json")
	if err != nil {
		panic(err)
	}

	app := gin.Default()
	//跨域访问 Use要放在路由前面
	app.Use(Cors())
	app.Static("/uploadfile", "./uploadfile")

	RegisterRouter(app)
	//创建数据库
	tool.Orm(cfg)

	app.Run(cfg.AppHost + ":" + cfg.AppPort)
}

func RegisterRouter(router *gin.Engine) {

	new(controller.UserController).Router(router)
	new(controller.ConversationController).Router(router)
	new(controller.MsgBroadController).Router(router)
	new(controller.ContributionController).Router(router)
	new(controller.FollowController).Router(router)
	new(controller.LikeController).Router(router)
}

//跨域访问请求
func Cors() gin.HandlerFunc {
	return func(c *gin.Context) {
		method := c.Request.Method
		c.Header("Access-Control-Allow-Origin", "*")
		c.Header("Access-Control-Allow-Headers", "Content-Type,AccessToken,X-CSRF-Token, Authorization, Token")
		c.Header("Access-Control-Allow-Methods", "POST, GET, OPTIONS")
		c.Header("Access-Control-Expose-Headers", "Content-Length, Access-Control-Allow-Origin, Access-Control-Allow-Headers, Content-Type")
		c.Header("Access-Control-Allow-Credentials", "true")
		if method == "OPTIONS" {
			c.AbortWithStatus(http.StatusNoContent)
		}
		c.Next()
	}
}
