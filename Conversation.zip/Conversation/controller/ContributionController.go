package controller

import (
	"Conversation/param"
	"Conversation/service"
	"Conversation/tool"
	"github.com/gin-gonic/gin"
	"strconv"
	"time"
)

type ContributionController struct {
}

func (cc *ContributionController) Router(e *gin.Engine) {
	//获取稿件信息
	e.GET("/api/contribution_all", cc.ContributionAll)
	//获取我的稿件
	e.GET("/api/contribution_my", cc.ContributionMy)
	//编辑稿件
	e.POST("/api/contribution_edit", cc.ContributionEdit)

}

func (cc *ContributionController) ContributionAll(c *gin.Context) {
	conService := service.ContributionService{}
	cont, err := conService.CtbService()
	if err != nil {
		tool.Failed(c, "获取稿件数据失败")
		return
	}
	tool.Success(c, cont)
}

func (cc *ContributionController) ContributionMy(c *gin.Context) {
	user := c.Query("user_id")
	uid, err := strconv.Atoi(user)
	if err != nil {
		tool.Failed(c, "参数解析失败！")
		return
	}

	cs := service.ContributionService{}
	con, err := cs.ContributionMyService(uid)
	if err != nil {
		tool.Failed(c, "获取我的稿件数据失败")
		return
	}
	tool.Success(c, con)
}

func (cc *ContributionController) ContributionEdit(c *gin.Context) {
	cImage, err := c.FormFile("contribution_image")
	if err != nil {
		tool.Failed(c, "读取图片失败65")
		return
	}
	filename := "./uploadfile/" + strconv.FormatInt(time.Now().Unix(), 10) + cImage.Filename
	err = c.SaveUploadedFile(cImage, filename)
	if err != nil {
		tool.Failed(c, "图像上传失败")
		return
	}

	var cp param.ConvParam
	cp.TownTalkTitle = c.PostForm("town_talk_title")
	cp.TownTalkInfo = c.PostForm("town_talk_info")
	uid := c.PostForm("user_id")
	cp.UserId, err = strconv.Atoi(uid)
	if err != nil {
		tool.Failed(c, "稿件uid参数转换失败！")
		return
	}

	cs := service.ContributionService{}
	result, err := cs.ContributionEditService(cp, filename)
	if err != nil {
		tool.Failed(c, "操作稿件失败")
		return
	}
	if result != 0 {
		tool.Success(c, "编辑成功")
		return
	}
	tool.Failed(c, "编辑稿件失败")

}
