package controller

import (
	"Conversation/param"
	"Conversation/service"
	"Conversation/tool"
	"github.com/gin-gonic/gin"
	"net/http"
	"strconv"
	"time"
)

type UserController struct {
}

func (uc *UserController) Router(e *gin.Engine) {
	e.GET("/api/user_get", uc.GetUser)
	//获取用户信息
	e.GET("/api/user_info", uc.userInfo)
	//搜索用户
	e.GET("/api/search_user", uc.SerchUser)
	//点击用户后的显示
	e.GET("/api/searchOne_user", uc.SearchOneUser)
	//编辑用户信息
	e.POST("/api/user_edit", uc.EditUser)
	//修改头像
	e.POST("/api/upload_avatar", uc.UploadAvatar)
	//增加用户
	e.POST("/api/add_user", uc.AddUser)
	//删除用户
	e.GET("/api/delete_user", uc.DeleteUser)
}

func (uc *UserController) GetUser(c *gin.Context) {
	getService := service.UserService{}
	user, err := getService.GetUser()
	if err != nil {
		tool.Failed(c, "获取用户失败")
	}
	tool.Success(c, user)

}

func (uc *UserController) SearchOneUser(c *gin.Context) {
	un := c.Query("user_name")
	us := service.UserService{}
	user, err := us.GetUserName(un)
	if err != nil {
		tool.Failed(c, "获取用户失败")
		return
	}
	oneuser, err := us.SearchOneUser(un)
	if err != nil {
		tool.Failed(c, "搜索单一用户失败")
		return
	}
	c.JSON(http.StatusOK, map[string]interface{}{
		"code": 0,
		"msg":  "成功",
		"data": map[string]interface{}{
			"data": user,
			"list": oneuser,
		},
	})
}

//增加用户
func (uc *UserController) AddUser(c *gin.Context) {
	var AddUserParam param.EditUserParam
	if err := tool.Decode(c.Request.Body, &AddUserParam); err != nil {
		tool.Failed(c, "参数解析失败")
		return
	}
	userService := service.UserService{}
	exist, _ := userService.AddUserService(AddUserParam)
	if exist == 0 {
		tool.Failed(c, "用户名已存在")
		return
	}
	tool.Success(c, "增加用户成功")
}

//删除用户
func (uc *UserController) DeleteUser(c *gin.Context) {
	du := c.Query("id")
	if du == "" {
		tool.Failed(c, "用户id不能为空")
		return
	}
	userService := service.UserService{}
	exist, _ := userService.DeleteUserService(du)
	if exist == 0 {
		tool.Failed(c, "用户不存在")
		return
	}
	tool.Success(c, "删除成功")
}

//获取用户信息
func (uc *UserController) userInfo(c *gin.Context) {
	pageNum, pageSize, err := tool.Pagination(c)

	ucs := &service.UserService{}
	infos, err := ucs.Info(pageNum, pageSize)
	if err != nil {
		tool.Failed(c, "请求失败："+err.Error())
		return
	}

	//转换数据格式
	for _, info := range infos {
		if info.Image != "" {
			info.Image = "./uploadfile/" + info.Image
		}
	}
	tool.Success(c, infos)
}

//搜索用户
func (uc *UserController) SerchUser(c *gin.Context) {

	username := c.Query("user_name")
	if username == "" {
		tool.Failed(c, "重新输入用户名")
		return
	}
	userService := service.UserService{}
	userList, err := userService.SearchUsers(username)
	if err != nil {
		tool.Failed(c, "获取用户名失败")
		return
	}
	if len(userList) > 0 {
		tool.Success(c, userList)
		return
	}
	tool.Failed(c, "未获取到用户名")

}

//编辑用户信息
func (uc *UserController) EditUser(c *gin.Context) {

	//获取前端传来的参数
	var userEditParam param.EditUserParam
	if err := tool.Decode(c.Request.Body, &userEditParam); err != nil {
		tool.Failed(c, "参数解析失败")
		return
	}
	if userEditParam.BlackList != 0 {
		return
	}
	userService := service.UserService{}
	ue, err := userService.EditUser(userEditParam)
	if err != nil {
		tool.Failed(c, "编辑用户失败")
		return
	}
	tool.Success(c, ue)
}

//更新用户头像
func (uc *UserController) UploadAvatar(c *gin.Context) {
	uid := c.PostForm("id")
	formFile, err := c.FormFile("image")

	if err != nil {
		tool.Failed(c, "读取头像失败")
		return
	}
	//strconv数据类型转换{ 将当前时间戳time.Now().Unix()  转换为10位数的数字}
	filename := "./uploadfile/" + strconv.FormatInt(time.Now().Unix(), 10) + formFile.Filename
	err = c.SaveUploadedFile(formFile, filename)
	if err != nil {
		tool.Failed(c, "图像上传失败")
		return
	}
	userService := service.UserService{}
	path, err := userService.UploadAvatarService(uid, filename[1:])
	if err != nil {
		tool.Failed(c, "更新用户头像失败")
		return
	}
	if path != "" {
		tool.Success(c, "http://192.168.20.117:8090"+path)
		return
	}
	tool.Failed(c, "上传失败")

}
