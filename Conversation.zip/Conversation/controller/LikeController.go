package controller

import (
	"Conversation/service"
	"Conversation/tool"
	"github.com/gin-gonic/gin"
	"net/http"
	"strconv"
)

type LikeController struct {
}

func (lc *LikeController) Router(e *gin.Engine) {
	//谁赞过我
	e.GET("/api/like_me", lc.likeMe)
	//获取我的点赞
	e.GET("/api/like_you", lc.likeYou)
	//添加点赞
	e.GET("/api/like_add", lc.likeAdd)
	//取消点赞
	e.GET("/api/like_cancel", lc.likeCancel)
	//我的收藏
	e.GET("/api/collect", lc.collect)
	//添加收藏
	e.GET("/api/collect_add", lc.collectAdd)
	//取消收藏
	e.GET("/api/collect_cancel", lc.collectCancel)
}

func (lc *LikeController) likeMe(c *gin.Context) {
	u := c.Query("user_id")
	uid, err := strconv.Atoi(u)
	if err != nil {
		tool.Failed(c, "参数转换失败！")
		return
	}

	ls := service.LikeService{}
	user, con, err := ls.LikeMe(uid)
	if err != nil {
		tool.Failed(c, "获取点赞数据失败！")
		return
	}

	c.JSON(http.StatusOK, map[string]interface{}{
		"code": 1,
		"msg":  "成功",
		"data": map[string]interface{}{
			"user":         user,
			"contribution": con,
		},
	})

}

func (lc *LikeController) likeYou(c *gin.Context) {
	u := c.Query("user_id")
	uid, err := strconv.Atoi(u)
	if err != nil {
		tool.Failed(c, "参数转换失败！")
		return
	}
	ls := service.LikeService{}
	contribution, err := ls.LikeYou(uid)
	if err != nil {
		tool.Failed(c, "获取我的点赞失败！")
		return
	}
	tool.Success(c, contribution)
}

func (lc *LikeController) likeAdd(c *gin.Context) {
	u := c.Query("user_id")
	con := c.Query("cid")
	uid, err := strconv.Atoi(u)
	cid, err := strconv.Atoi(con)
	if err != nil {
		tool.Failed(c, "参数转换失败！")
		return
	}

	ls := service.LikeService{}
	result, err := ls.LikeAdd(uid, cid)
	if err != nil {
		tool.Failed(c, "添加点赞失败")
		return
	}
	if result != 0 {
		tool.Success(c, "添加点赞成功")
		return
	}
	tool.Failed(c, "添加点赞失败")
}

func (lc *LikeController) likeCancel(c *gin.Context) {
	u := c.Query("user_id")
	con := c.Query("cid")
	uid, err := strconv.Atoi(u)
	cid, err := strconv.Atoi(con)
	if err != nil {
		tool.Failed(c, "参数转换失败！")
		return
	}

	ls := service.LikeService{}
	result, err := ls.LikeCancel(uid, cid)
	if err != nil {
		tool.Failed(c, "请求更改数据失败")
		return
	}
	if result != 0 {
		tool.Success(c, "取消点赞成功")
		return
	}
	tool.Failed(c, "取消点赞失败")
}

func (lc *LikeController) collect(c *gin.Context) {
	u := c.Query("user_id")
	uid, err := strconv.Atoi(u)
	if err != nil {
		tool.Failed(c, "参数转换失败")
		return
	}

	ls := service.LikeService{}
	con, err := ls.Collect(uid)
	if err != nil {
		tool.Failed(c, "获取收藏数据失败")
		return
	}
	tool.Success(c, con)

}

func (lc *LikeController) collectAdd(c *gin.Context) {
	u := c.Query("user_id")
	con := c.Query("cid")
	uid, err := strconv.Atoi(u)
	cid, err := strconv.Atoi(con)
	if err != nil {
		tool.Failed(c, "参数转换失败！")
		return
	}

	ls := service.LikeService{}
	result, err := ls.CollectAdd(uid, cid)
	if err != nil {
		tool.Failed(c, "操作数据库失败")
		return
	}
	if result != 0 {
		tool.Success(c, "收藏添加成功")
		return
	}
	tool.Failed(c, "收藏添加失败")

}

func (lc *LikeController) collectCancel(c *gin.Context) {
	u := c.Query("user_id")
	con := c.Query("cid")
	uid, err := strconv.Atoi(u)
	cid, err := strconv.Atoi(con)
	if err != nil {
		tool.Failed(c, "参数转换失败！")
		return
	}

	ls := service.LikeService{}
	result, err := ls.CollectCancel(uid, cid)
	if err != nil {
		tool.Failed(c, "操作数据库失败")
		return
	}
	if result != 0 {
		tool.Success(c, "取消收藏成功")
		return
	}
	tool.Failed(c, "取消收藏失败")
}
