package controller

import (
	"Conversation/param"
	"Conversation/service"
	"Conversation/tool"
	"github.com/gin-gonic/gin"
	"strconv"
	"time"
)

type ConversationController struct {
}

func (conv *ConversationController) Router(e *gin.Engine) {
	//话题合集
	e.GET("/api/conv_allInfo", conv.convAllInfo)
	//搜索话题
	e.GET("/api/conv_search", conv.convSearch)
	e.GET("/api/conv_searchOne", conv.convSearchOne)
	//发布稿件
	e.POST("/api/conv_add", conv.convAdd)

}

//添加话题
func (conv *ConversationController) convAdd(c *gin.Context) {
	cImage, err := c.FormFile("contribution_image")
	if err != nil {
		tool.Failed(c, "读取图片失败65")
		return
	}
	filename := "./uploadfile/" + strconv.FormatInt(time.Now().Unix(), 10) + cImage.Filename
	err = c.SaveUploadedFile(cImage, filename)
	if err != nil {
		tool.Failed(c, "图像上传失败")
		return
	}

	var cp param.ConvParam
	cp.TownTalkTitle = c.PostForm("town_talk_title")
	cp.TownTalkInfo = c.PostForm("town_talk_info")
	uid := c.PostForm("user_id")
	cp.UserId, err = strconv.Atoi(uid)
	if err != nil {
		tool.Failed(c, "uid参数转换失败")
		return
	}

	convService := service.ConversationService{}
	result, err := convService.ConvAdd(cp, filename[1:])
	if err != nil {
		tool.Failed(c, "投稿失败，话题名称已存在或数据有误")
		return
	}
	if result != 0 {
		tool.Success(c, "投稿成功")
		return
	}
	tool.Failed(c, "投稿失败，话题名称已存在或数据有误")

}

//话题合集
func (conv *ConversationController) convAllInfo(c *gin.Context) {

	//pageNum, pageSize, err := tool.Pagination(c)
	pn := c.DefaultQuery("pageNum", "1")
	ps := c.DefaultQuery("pageSize", "6")
	pageNum, err := strconv.Atoi(pn)
	pageSize, err := strconv.Atoi(ps)
	if err != nil {
		tool.Failed(c, "参数转换失败")
		return
	}

	convS := &service.ConversationService{}
	convInfo, err := convS.ConvAllInfo(pageSize, pageNum)
	if err != nil {
		tool.Failed(c, "请求失败："+err.Error())
		return
	}

	tool.Success(c, convInfo)
}

//话题搜索
func (conv *ConversationController) convSearch(c *gin.Context) {
	convTitle := c.Query("town_talk_title")
	if convTitle == "" {
		tool.Failed(c, "重新输入话题名称")
		return
	}
	convSc := &service.ConversationService{}
	convList, err := convSc.ConvSearchInfo(convTitle)
	if err != nil {
		tool.Failed(c, "话题搜索失败")
		return
	}
	if len(convList) > 0 {
		tool.Success(c, convList)
		return
	}
	tool.Failed(c, "话题搜索失败")
}

//用户点击话题后的显示
func (conv *ConversationController) convSearchOne(c *gin.Context) {
	convTitle := c.Query("town_talk_title")

	convSc := &service.ConversationService{}
	convOne, err := convSc.ConvSearchOne(convTitle)
	if err != nil {
		tool.Failed(c, "话题显示失败")
		return
	}
	if len(convOne) > 0 {
		tool.Success(c, convOne)
		return
	}
	tool.Failed(c, "话题显示失败")
}
