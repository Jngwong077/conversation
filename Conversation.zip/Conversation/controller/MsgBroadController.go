package controller

import (
	"Conversation/param"
	"Conversation/service"
	"Conversation/tool"
	"github.com/gin-gonic/gin"
	"strconv"
)

type MsgBroadController struct {
}

func (mb *MsgBroadController) Router(e *gin.Engine) {
	//获取留言信息
	e.GET("/api/meg_info", mb.MsgInfo)
	//添加评论
	e.POST("/api/msg_add", mb.MsgAdd)
	//举报评论
	e.GET("/api/msg_report", mb.MsgReport)
	//置顶评论
	e.GET("/api/msg_top", mb.MsgTop)
	//回复评论
	e.GET("/api/msg_reply", mb.MsgReply)
	//删除评论
	e.GET("/api/msg_delete", mb.MsgDelete)
}

func (mb *MsgBroadController) MsgInfo(c *gin.Context) {
	conId := c.Query("contribution_id")
	cid, err := strconv.Atoi(conId)
	if err != nil {
		tool.Failed(c, "数据转换失败")
		return
	}
	msgService := service.MsgBroadService{}
	msgInfo, err := msgService.MsgService(cid)
	if err != nil {
		tool.Failed(c, "请求留言板数据失败")
		return
	}
	tool.Success(c, msgInfo)
}

func (mb *MsgBroadController) MsgAdd(c *gin.Context) {
	var mp param.MsgBroadParam
	err := tool.Decode(c.Request.Body, &mp)
	if err != nil {
		tool.Failed(c, "参数解析失败")
		return
	}
	msgadd := service.MsgBroadService{}
	result, err := msgadd.MsgAddService(mp)
	if err != nil {
		tool.Failed(c, "添加留言失败")
		return
	}
	if result != 0 {
		tool.Success(c, "留言添加成功")
		return
	}
	tool.Failed(c, "添加留言失败")
}

func (mb *MsgBroadController) MsgReport(c *gin.Context) {
	ms := service.MsgBroadService{}
	ms.MsgReportService()

}

func (mb *MsgBroadController) MsgTop(c *gin.Context) {
	msgid := c.Query("id")
	mid, err := strconv.Atoi(msgid)
	if err != nil {
		tool.Failed(c, "类型转换失败！")
		return
	}
	ms := service.MsgBroadService{}
	result, err := ms.MsgTopService(mid)
	if err != nil {
		tool.Failed(c, "置顶评论操作失败")
		return
	}
	if result != 0 {
		tool.Success(c, "置顶评论成功")
		return
	}
	tool.Failed(c, "置顶评论失败")

}

func (mb *MsgBroadController) MsgReply(c *gin.Context) {
	ms := service.MsgBroadService{}
	ms.MsgReplyService()
}

func (mb *MsgBroadController) MsgDelete(c *gin.Context) {
	ms := service.MsgBroadService{}
	ms.MsgDeleteService()
}
