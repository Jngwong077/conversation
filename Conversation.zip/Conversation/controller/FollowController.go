package controller

import (
	"Conversation/service"
	"Conversation/tool"
	"github.com/gin-gonic/gin"

	"strconv"
)

type FollowController struct {
}

func (fc *FollowController) Router(e *gin.Engine) {
	//获取用户关注信息
	e.GET("/api/follow_get", fc.followGet)
	//获取粉丝信息
	e.GET("/api/fan_get", fc.fanGet)
	//获取互相关注信息
	e.GET("/api/follow_eachOther", fc.followEach)
	//添加关注
	e.GET("/api/follow_add", fc.followAdd)
	//取消关注
	e.GET("/api/follow_cancel", fc.followCancel)

}
func (fc *FollowController) followAdd(c *gin.Context) {
	u1 := c.Query("user_id")
	u2 := c.Query("user_id2")
	uid, err := strconv.Atoi(u1)
	uid2, err := strconv.Atoi(u2)
	if err != nil {
		tool.Failed(c, "参数转换失败")
		return
	}
	fs := service.FollowService{}
	result, err := fs.FollowAdd(uid, uid2)
	if err != nil {
		tool.Failed(c, "添加关注失败")
		return
	}
	if result == 0 {
		tool.Failed(c, "请求失败")
		return
	}
	tool.Success(c, "添加关注成功")

}

func (fc *FollowController) followCancel(c *gin.Context) {
	u1 := c.Query("user_id")
	u2 := c.Query("user_id2")
	uid, err := strconv.Atoi(u1)
	uid2, err := strconv.Atoi(u2)
	if err != nil {
		tool.Failed(c, "参数转换失败")
		return
	}
	fs := service.FollowService{}
	result, err := fs.FollowCancel(uid, uid2)
	if err != nil {
		tool.Failed(c, "取消关注失败")
		return
	}
	if result == 0 {
		tool.Failed(c, "请求失败")
		return
	}
	tool.Success(c, "取消关注成功")
}

func (fc *FollowController) fanGet(c *gin.Context) {
	u := c.Query("user_id")
	uid, err := strconv.Atoi(u)
	if err != nil {
		tool.Failed(c, "参数转换失败")
		return
	}
	fs := service.FollowService{}
	fanUser, err := fs.FanGet(uid)
	if err != nil {
		tool.Failed(c, "请求失败")
		return
	}
	tool.Success(c, fanUser)
}

func (fc *FollowController) followGet(c *gin.Context) {
	u := c.Query("user_id")
	uid, err := strconv.Atoi(u)
	if err != nil {
		tool.Failed(c, "参数转换失败")
		return
	}
	fs := service.FollowService{}
	followUser, err := fs.FollowGet(uid)
	if err != nil {
		tool.Failed(c, "请求失败")
		return
	}
	tool.Success(c, followUser)

}

func (fc *FollowController) followEach(c *gin.Context) {
	u := c.Query("user_id")
	uid, err := strconv.Atoi(u)
	if err != nil {
		tool.Failed(c, "参数转换失败")
		return
	}
	fs := service.FollowService{}
	followUser, err := fs.FollowEach(uid)
	if err != nil {
		tool.Failed(c, "请求失败")
		return
	}
	tool.Success(c, followUser)
}
