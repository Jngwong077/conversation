package service

import (
	"Conversation/dao"
	"Conversation/model"
	"Conversation/param"
)

type ContributionService struct {
}

func (cs *ContributionService) CtbService() ([]model.Contribution, error) {

	return dao.NewContributionDao().CtbDao()
}

func (cs *ContributionService) ContributionMyService(uid int) ([]model.Contribution, error) {
	return dao.NewContributionDao().ContributionMyDao(uid)
}

func (cs *ContributionService) ContributionEditService(cp param.ConvParam, filename string) (int64, error) {
	return dao.NewContributionDao().ContributionEditDao(cp, filename)
}
