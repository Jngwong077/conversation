package service

import (
	"Conversation/dao"
	"Conversation/model"
	"Conversation/param"
)

type MsgBroadService struct {
}

func (ms *MsgBroadService) MsgService(cid int) ([]model.MsgBroad, error) {
	return dao.NewMsgBroadDao().MsgDao(cid)
}

func (ms *MsgBroadService) MsgAddService(mp param.MsgBroadParam) (int, error) {
	return dao.NewMsgBroadDao().MsgAddDao(mp)
}

func (ms *MsgBroadService) MsgReportService() (int, error) {
	return dao.NewMsgBroadDao().MsgReportDao()
}

func (ms *MsgBroadService) MsgTopService(mid int) (int, error) {
	return dao.NewMsgBroadDao().MsgTopDao(mid)
}

func (ms *MsgBroadService) MsgReplyService() (int, error) {
	return dao.NewMsgBroadDao().MsgReplyDao()
}

func (ms *MsgBroadService) MsgDeleteService() (int, error) {
	return dao.NewMsgBroadDao().MsgDeleteDao()
}
