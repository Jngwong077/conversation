package service

import (
	"Conversation/dao"
	"Conversation/model"
)

type LikeService struct {
}

func (ls *LikeService) LikeMe(uid int) ([]model.User, []model.Contribution, error) {
	return dao.NewLikeAndCollectDao().LikeMeDao(uid)
}

func (ls *LikeService) LikeYou(uid int) ([]model.Contribution, error) {
	return dao.NewLikeAndCollectDao().LikeYouDao(uid)
}

func (ls *LikeService) LikeAdd(uid int, cid int) (int, error) {
	return dao.NewLikeAndCollectDao().LikeAddDao(uid, cid)
}
func (ls *LikeService) LikeCancel(uid int, cid int) (int, error) {
	return dao.NewLikeAndCollectDao().LikeCancelDao(uid, cid)
}

func (ls *LikeService) Collect(uid int) ([]model.Contribution, error) {
	return dao.NewLikeAndCollectDao().CollectDao(uid)
}

func (ls *LikeService) CollectAdd(uid int, cid int) (int, error) {
	return dao.NewLikeAndCollectDao().CollectAddDao(uid, cid)
}

func (ls *LikeService) CollectCancel(uid int, cid int) (int, error) {
	return dao.NewLikeAndCollectDao().CollectCancelDao(uid, cid)
}
