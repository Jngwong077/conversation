package service

import (
	"Conversation/dao"
	"Conversation/model"
	"Conversation/param"
)

type ConversationService struct {
}

func (cs *ConversationService) ConvAdd(convParam param.ConvParam, filename string) (int64, error) {
	return dao.NewConvInfo().ConvAddDao(convParam, filename)
}

func (cs *ConversationService) ConvAllInfo(pageSize int, pageNum int) ([]model.Conversation, error) {
	return dao.NewConvInfo().ConvInfo(pageSize, (pageNum-1)*pageSize)
}

func (cs *ConversationService) ConvSearchInfo(convTitle string) ([]model.Conversation, error) {
	return dao.NewConvInfo().SearchConv(convTitle)
}

func (cs *ConversationService) ConvSearchOne(convTitle string) ([]model.Contribution, error) {
	return dao.NewConvInfo().SearchConvOne(convTitle)
}
