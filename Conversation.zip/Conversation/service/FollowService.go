package service

import (
	"Conversation/dao"
	"Conversation/model"
)

type FollowService struct {
}

func (fs *FollowService) FanGet(uid int) ([]model.User, error) {
	return dao.NewFollowDao().FanGetDao(uid)
}

func (fs *FollowService) FollowGet(uid int) ([]model.User, error) {
	return dao.NewFollowDao().FollowGetDao(uid)
}

func (fs *FollowService) FollowEach(uid int) ([]model.User, error) {
	return dao.NewFollowDao().FollowEachDao(uid)
}

func (fs *FollowService) FollowAdd(uid int, uid2 int) (int, error) {
	return dao.NewFollowDao().FollowAddDao(uid, uid2)
}

func (fs *FollowService) FollowCancel(uid int, uid2 int) (int, error) {
	return dao.NewFollowDao().FollowCancelDao(uid, uid2)
}
