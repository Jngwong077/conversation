package service

import (
	"Conversation/dao"
	"Conversation/model"
	"Conversation/param"
)

type UserService struct {
}

func (us *UserService) GetUser() (*model.User, error) {
	return dao.NewUserInfo().GetUserDao()
}

func (us *UserService) GetUserName(un string) (*model.User, error) {
	return dao.NewUserInfo().GetUserNameDao(un)
}
func (us *UserService) SearchOneUser(un string) ([]model.Contribution, error) {
	return dao.NewUserInfo().SearchOneUserDao(un)
}

//获取用户信息
func (us *UserService) Info(pageNum int, pageSize int) ([]model.User, error) {
	return dao.NewUserInfo().QueryInfo(pageNum, pageSize)
}

//根据用户名搜索用户
func (us *UserService) SearchUsers(username string) ([]model.User, error) {
	return dao.NewUserInfo().QueryUser(username)
}

//编辑用户信息
func (us *UserService) EditUser(editParam param.EditUserParam) ([]model.User, error) {
	return dao.NewUserInfo().EditUser(editParam)
}

//增加用户
func (us *UserService) AddUserService(addParam param.EditUserParam) (int64, error) {
	return dao.NewUserInfo().AddUserDao(addParam)
}

//删除用户
func (us *UserService) DeleteUserService(id string) (int64, error) {
	return dao.NewUserInfo().DeleteUserDao(id)
}

func (us *UserService) UploadAvatarService(id string, filename string) (string, error) {
	result, err := dao.NewUserInfo().UploadAvaDao(id, filename)
	if result == 0 {
		return "", err
	}

	return filename, nil

}
