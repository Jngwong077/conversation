package tool

import (
	"encoding/json"
	"io"
)

type Dao struct {
	*Orme
}

func NewDao() *Dao {
	return &Dao{DbEngine}
}

//参数解析的方法
func Decode(io io.ReadCloser, v interface{}) error {
	return json.NewDecoder(io).Decode(v)
}

//func (d *Dao) SearchUser(uid int) (int, error) {
//	var user []model.User
//	err := d.Where("id = ?", uid).Find(&user)
//	if err != nil {
//		fmt.Println("查询用户表失败！")
//		return 0, err
//	}
//	return 1, err
//}
