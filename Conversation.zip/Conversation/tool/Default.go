package tool

import (
	"github.com/gin-gonic/gin"
	"net/http"
)

const (
	SUCCESS int = 0
	FAILED  int = 1
)

func Success(c *gin.Context, v interface{}) {
	c.JSON(http.StatusOK, map[string]interface{}{
		"code": SUCCESS,
		"msg":  "成功",
		"data": v,
	})
}

func Failed(c *gin.Context, v interface{})  {
	c.JSON(http.StatusOK, map[string]interface{}{
		"code": FAILED,
		"msg":  v,

	})
}