package tool

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"strconv"
)

func Pagination(ctx *gin.Context) (pageStr int, num int, err error) {
	limit := ctx.DefaultQuery("page_size", "6")
	pageNumber := ctx.DefaultQuery("page_number", "1")

	limitInt, err := strconv.Atoi(limit)

	if err != nil || limitInt < 0 {
		return 0, 0, err
	}
	pageNumberInt, err := strconv.Atoi(pageNumber)

	if err != nil || pageNumberInt < 0 {
		return 0, 0, err
	}
	if pageNumberInt != 0 {
		pageNumberInt--
	}
	offsetInt := limitInt * pageNumberInt

	fmt.Println(" limit %d offset %d", limitInt+1, offsetInt)

	return pageStr, limitInt, nil
}
