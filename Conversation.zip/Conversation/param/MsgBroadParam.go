package param

type MsgBroadParam struct {
	ContributionId int `json:"contribution_id"`
	UserId int `json:"user_id"`
	Msg string `json:"msg"`
}
