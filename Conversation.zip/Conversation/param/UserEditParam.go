package param

type EditUserParam struct {
	Id        int64  `json:"id"`
	UserName  string `json:"user_name"`
	Image     string `json:"image"`
	Autograph string `json:"autograph"`
	Identity  string `json:"identity"`
	BlackList int `json:"black_list"`
}
