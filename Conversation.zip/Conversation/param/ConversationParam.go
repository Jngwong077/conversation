package param

type ConvParam struct {
	UserId        int    `json:"user_id"`
	TownTalkInfo  string `json:"town_talk_info"`
	TownTalkTitle string `json:"town_talk_title"`
}
